<?php
/**
 * Sample listings data provider.
 * Arizona-flavored dummy data for demo purposes.
 */
class Housemajik_Sample_Data {

	/**
	 * Get sample listings.
	 */
	public static function get_listings( $filters = array() ) {
		$all_listings = self::get_all_sample_listings();
		
		// Apply filters
		$filtered = array();
		foreach ( $all_listings as $listing ) {
			if ( self::matches_filters( $listing, $filters ) ) {
				$filtered[] = $listing;
			}
		}
		
		return $filtered;
	}

	/**
	 * Check if listing matches filters.
	 */
	private static function matches_filters( $listing, $filters ) {
		// Location filter (city match)
		if ( ! empty( $filters['location'] ) ) {
			$location_lower = strtolower( $filters['location'] );
			$city_lower = strtolower( $listing['city'] );
			if ( strpos( $city_lower, $location_lower ) === false ) {
				return false;
			}
		}
		
		// Beds filter
		if ( ! empty( $filters['beds'] ) ) {
			if ( $filters['beds_mode'] === 'exactly' ) {
				if ( $listing['beds'] != $filters['beds'] ) {
					return false;
				}
			} else {
				if ( $listing['beds'] < $filters['beds'] ) {
					return false;
				}
			}
		}
		
		// Baths filter
		if ( ! empty( $filters['baths'] ) ) {
			if ( $filters['baths_mode'] === 'exactly' ) {
				if ( $listing['baths'] != $filters['baths'] ) {
					return false;
				}
			} else {
				if ( $listing['baths'] < $filters['baths'] ) {
					return false;
				}
			}
		}
		
		// Max price filter
		if ( ! empty( $filters['max_price'] ) ) {
			if ( $listing['price'] > $filters['max_price'] ) {
				return false;
			}
		}
		
		// Garage filter
		if ( ! empty( $filters['garage'] ) && $filters['garage'] !== 'dont_care' ) {
			$has_garage = ! empty( $listing['garage'] );
			if ( $filters['garage'] === 'yes' && ! $has_garage ) {
				return false;
			}
			if ( $filters['garage'] === 'no' && $has_garage ) {
				return false;
			}
		}
		
		return true;
	}

	/**
	 * Get single listing by ID.
	 */
	public static function get_listing( $listing_id ) {
		$all_listings = self::get_all_sample_listings();
		
		foreach ( $all_listings as $listing ) {
			if ( $listing['id'] === $listing_id ) {
				return $listing;
			}
		}
		
		return null;
	}

	/**
	 * All sample listings.
	 */
	private static function get_all_sample_listings() {
		return array(
			array(
				'id' => 'SAMPLE-001',
				'address' => '4523 E Desert Willow Drive',
				'city' => 'Phoenix',
				'state' => 'AZ',
				'zip' => '85044',
				'price' => 485000,
				'beds' => 3,
				'baths' => 2.5,
				'sqft' => 2100,
				'garage' => '2-car attached',
				'lot_size' => '8,500 sq ft',
				'year_built' => 2018,
				'property_type' => 'Single Family',
				'photos' => array(
					HOUSEMAJIK_PLUGIN_URL . 'public/images/sample-1-main.jpg',
				),
				'remarks' => 'Stunning desert contemporary with an open floor plan and mountain views. Modern kitchen features quartz countertops, stainless appliances, and large island perfect for entertaining. Master suite offers walk-in closet and spa-like bath with dual vanity. Low-maintenance desert landscaping with covered patio. Community pool and walking trails. Close to South Mountain Park.',
				'lat' => 33.3464,
				'lng' => -112.0022,
			),
			array(
				'id' => 'SAMPLE-002',
				'address' => '1847 N Mountain View Road',
				'city' => 'Scottsdale',
				'state' => 'AZ',
				'zip' => '85251',
				'price' => 725000,
				'beds' => 4,
				'baths' => 3,
				'sqft' => 2850,
				'garage' => '3-car attached',
				'lot_size' => '12,200 sq ft',
				'year_built' => 2015,
				'property_type' => 'Single Family',
				'photos' => array(
					HOUSEMAJIK_PLUGIN_URL . 'public/images/sample-2-main.jpg',
				),
				'remarks' => 'Luxurious Scottsdale home with resort-style backyard featuring sparkling pool, built-in BBQ, and covered ramada. Gourmet kitchen with upgraded cabinetry, granite counters, and walk-in pantry. Spacious great room with soaring ceilings and fireplace. Split floor plan with generous master retreat. Finished 3-car garage with epoxy flooring. Premium lot backing to desert preserve. Award-winning schools nearby.',
				'lat' => 33.4942,
				'lng' => -111.9261,
			),
			array(
				'id' => 'SAMPLE-003',
				'address' => '8912 W Sunset Canyon Lane',
				'city' => 'Peoria',
				'state' => 'AZ',
				'zip' => '85383',
				'price' => 395000,
				'beds' => 3,
				'baths' => 2,
				'sqft' => 1820,
				'garage' => '2-car attached',
				'lot_size' => '6,800 sq ft',
				'year_built' => 2020,
				'property_type' => 'Single Family',
				'photos' => array(
					HOUSEMAJIK_PLUGIN_URL . 'public/images/sample-3-main.jpg',
				),
				'remarks' => 'Like-new construction in desirable Peoria neighborhood. Bright and airy open concept with modern finishes throughout. Kitchen boasts white cabinetry, subway tile backsplash, and stainless steel appliances. Large master with ensuite bath and walk-in closet. Covered patio overlooks low-maintenance backyard. Community amenities include playground and dog park. Easy access to Loop 101.',
				'lat' => 33.5806,
				'lng' => -112.2379,
			),
			array(
				'id' => 'SAMPLE-004',
				'address' => '2156 E Saguaro Blossom Way',
				'city' => 'Gilbert',
				'state' => 'AZ',
				'zip' => '85296',
				'price' => 550000,
				'beds' => 4,
				'baths' => 2.5,
				'sqft' => 2450,
				'garage' => '3-car tandem',
				'lot_size' => '9,200 sq ft',
				'year_built' => 2017,
				'property_type' => 'Single Family',
				'photos' => array(
					HOUSEMAJIK_PLUGIN_URL . 'public/images/sample-4-main.jpg',
				),
				'remarks' => 'Family-friendly home in top-rated Gilbert school district. Formal living and dining rooms plus open family room. Well-appointed kitchen with island, granite, and plenty of storage. Four bedrooms upstairs including spacious loft area. Extended covered patio and grassy backyard ideal for play. Tandem 3-car garage with built-in cabinets. Walking distance to parks, shopping, and dining.',
				'lat' => 33.3102,
				'lng' => -111.7468,
			),
			array(
				'id' => 'SAMPLE-005',
				'address' => '5634 N Catalina Vista Drive',
				'city' => 'Tucson',
				'state' => 'AZ',
				'zip' => '85718',
				'price' => 425000,
				'beds' => 3,
				'baths' => 2,
				'sqft' => 1950,
				'garage' => '2-car attached',
				'lot_size' => '10,500 sq ft',
				'year_built' => 2016,
				'property_type' => 'Single Family',
				'photos' => array(
					HOUSEMAJIK_PLUGIN_URL . 'public/images/sample-5-main.jpg',
				),
				'remarks' => 'Tucson gem with breathtaking Catalina Mountain views. Open living space flows to covered patio perfect for enjoying Arizona sunsets. Updated kitchen with newer appliances and beautiful tile work. Split bedroom layout provides privacy. Newer HVAC and roof. Mature desert landscaping with native plants. Close to hiking trails and shopping. Quiet cul-de-sac location.',
				'lat' => 32.2956,
				'lng' => -110.8761,
			),
			array(
				'id' => 'SAMPLE-006',
				'address' => '7289 W Monsoon Drive',
				'city' => 'Chandler',
				'state' => 'AZ',
				'zip' => '85226',
				'price' => 495000,
				'beds' => 4,
				'baths' => 3,
				'sqft' => 2300,
				'garage' => '2-car attached',
				'lot_size' => '7,500 sq ft',
				'year_built' => 2019,
				'property_type' => 'Single Family',
				'photos' => array(
					HOUSEMAJIK_PLUGIN_URL . 'public/images/sample-6-main.jpg',
				),
				'remarks' => 'Contemporary Chandler home with flexible floor plan. Downstairs bedroom and full bath perfect for guests or home office. Gourmet kitchen features large island, walk-in pantry, and dining nook. Upstairs loft provides additional living space. Master suite with luxurious bath and oversized closet. Energy-efficient construction with smart home features. Community pool, spa, and fitness center.',
				'lat' => 33.2826,
				'lng' => -111.9517,
			),
			array(
				'id' => 'SAMPLE-007',
				'address' => '3421 E Prickly Pear Path',
				'city' => 'Mesa',
				'state' => 'AZ',
				'zip' => '85213',
				'price' => 365000,
				'beds' => 3,
				'baths' => 2,
				'sqft' => 1680,
				'garage' => '2-car attached',
				'lot_size' => '6,200 sq ft',
				'year_built' => 2021,
				'property_type' => 'Single Family',
				'photos' => array(
					HOUSEMAJIK_PLUGIN_URL . 'public/images/sample-7-main.jpg',
				),
				'remarks' => 'Move-in ready Mesa home in established neighborhood. Thoughtfully designed open layout maximizes space. Kitchen includes breakfast bar, pantry, and all appliances. Neutral palette throughout with durable flooring. Master bedroom features private bath and walk-in closet. Covered patio and easy-care landscaping. Great location near schools, parks, and freeway access.',
				'lat' => 33.4019,
				'lng' => -111.7249,
			),
			array(
				'id' => 'SAMPLE-008',
				'address' => '9845 N Ironwood Ridge Road',
				'city' => 'Fountain Hills',
				'state' => 'AZ',
				'zip' => '85268',
				'price' => 875000,
				'beds' => 5,
				'baths' => 4,
				'sqft' => 3600,
				'garage' => '3-car attached',
				'lot_size' => '15,800 sq ft',
				'year_built' => 2014,
				'property_type' => 'Single Family',
				'photos' => array(
					HOUSEMAJIK_PLUGIN_URL . 'public/images/sample-8-main.jpg',
				),
				'remarks' => 'Spectacular Fountain Hills estate on premium lot with panoramic mountain and city views. Chef\'s kitchen with double ovens, gas cooktop, and butler\'s pantry. Great room with soaring ceilings, custom built-ins, and stacked stone fireplace. Luxurious master wing with sitting area, spa bath, and his/her closets. Resort-style backyard with heated pool, spa, ramada, and outdoor kitchen. Casita with separate entrance. Five-car garage space.',
				'lat' => 33.6170,
				'lng' => -111.7318,
			),
		);
	}
}
