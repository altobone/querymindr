<?php
/**
 * Security utilities.
 */
class Housemajik_Security {

	/**
	 * Verify nonce for AJAX requests.
	 */
	public static function verify_ajax_nonce() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'housemajik_ajax' ) ) {
			wp_send_json_error( array( 'message' => 'Security check failed.' ), 403 );
			exit;
		}
	}

	/**
	 * Check honeypot field.
	 */
	public static function check_honeypot() {
		if ( ! empty( $_POST['website'] ) ) {
			wp_send_json_error( array( 'message' => 'Invalid submission.' ), 403 );
			exit;
		}
	}

	/**
	 * Rate limit check.
	 */
	public static function check_rate_limit( $action = 'search' ) {
		$ip = self::get_client_ip();
		$transient_key = 'housemajik_rate_' . $action . '_' . md5( $ip );
		
		$attempts = get_transient( $transient_key );
		$limit = (int) get_option( 'housemajik_rate_limit_searches', 10 );
		$window = (int) get_option( 'housemajik_rate_limit_window', 3600 );
		
		if ( $attempts === false ) {
			set_transient( $transient_key, 1, $window );
			return true;
		}
		
		if ( $attempts >= $limit ) {
			wp_send_json_error( array( 
				'message' => 'Too many requests. Please try again later.' 
			), 429 );
			exit;
		}
		
		set_transient( $transient_key, $attempts + 1, $window );
		return true;
	}

	/**
	 * Check AI daily usage cap.
	 */
	public static function check_ai_cap() {
		$today = date( 'Y-m-d' );
		$usage_date = get_option( 'housemajik_ai_usage_date', '' );
		$usage_count = (int) get_option( 'housemajik_ai_usage_today', 0 );
		
		// Reset counter if new day
		if ( $usage_date !== $today ) {
			update_option( 'housemajik_ai_usage_date', $today );
			update_option( 'housemajik_ai_usage_today', 0 );
			$usage_count = 0;
		}
		
		$daily_cap = (int) get_option( 'housemajik_ai_daily_cap', 1000 );
		
		if ( $usage_count >= $daily_cap ) {
			return false;
		}
		
		return true;
	}

	/**
	 * Increment AI usage counter.
	 */
	public static function increment_ai_usage() {
		$usage_count = (int) get_option( 'housemajik_ai_usage_today', 0 );
		update_option( 'housemajik_ai_usage_today', $usage_count + 1 );
	}

	/**
	 * Get client IP address.
	 */
	public static function get_client_ip() {
		$ip = '';
		
		if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		
		return sanitize_text_field( $ip );
	}

	/**
	 * Sanitize search parameters.
	 */
	public static function sanitize_search_params( $params ) {
		return array(
			'dream_home' => isset( $params['dream_home'] ) ? sanitize_textarea_field( $params['dream_home'] ) : '',
			'dont_want' => isset( $params['dont_want'] ) ? sanitize_textarea_field( $params['dont_want'] ) : '',
			'location' => isset( $params['location'] ) ? sanitize_text_field( $params['location'] ) : '',
			'beds' => isset( $params['beds'] ) ? absint( $params['beds'] ) : 0,
			'beds_mode' => isset( $params['beds_mode'] ) && in_array( $params['beds_mode'], array( 'exactly', 'at_least' ) ) ? $params['beds_mode'] : 'exactly',
			'baths' => isset( $params['baths'] ) ? floatval( $params['baths'] ) : 0,
			'baths_mode' => isset( $params['baths_mode'] ) && in_array( $params['baths_mode'], array( 'exactly', 'at_least' ) ) ? $params['baths_mode'] : 'exactly',
			'max_price' => isset( $params['max_price'] ) ? absint( $params['max_price'] ) : 0,
			'garage' => isset( $params['garage'] ) && in_array( $params['garage'], array( 'yes', 'no', 'dont_care' ) ) ? $params['garage'] : 'dont_care',
		);
	}

	/**
	 * Sanitize email.
	 */
	public static function sanitize_email( $email ) {
		return sanitize_email( trim( $email ) );
	}

	/**
	 * Sanitize phone.
	 */
	public static function sanitize_phone( $phone ) {
		return sanitize_text_field( trim( $phone ) );
	}

	/**
	 * Get or create session ID.
	 */
	public static function get_session_id() {
		if ( ! empty( $_COOKIE['housemajik_session_id'] ) ) {
			return sanitize_text_field( wp_unslash( $_COOKIE['housemajik_session_id'] ) );
		}

		$session_id = wp_generate_uuid4();

		if ( ! headers_sent() ) {
			setcookie(
				'housemajik_session_id',
				$session_id,
				array(
					'expires'  => time() + WEEK_IN_SECONDS,
					'path'     => defined( 'COOKIEPATH' ) && COOKIEPATH ? COOKIEPATH : '/',
					'domain'   => defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '',
					'secure'   => is_ssl(),
					'httponly' => true,
					'samesite' => 'Lax',
				)
			);
			$_COOKIE['housemajik_session_id'] = $session_id;
		}

		return $session_id;
	}

	/**
	 * Remember the page that hosts the search shortcode.
	 */
	public static function set_search_page_url( $url ) {
		$url = esc_url_raw( $url );
		if ( ! $url ) {
			return;
		}

		$safe = wp_validate_redirect( $url, false );
		if ( ! $safe ) {
			return;
		}

		if ( ! headers_sent() ) {
			setcookie(
				'housemajik_search_url',
				$safe,
				array(
					'expires'  => time() + WEEK_IN_SECONDS,
					'path'     => defined( 'COOKIEPATH' ) && COOKIEPATH ? COOKIEPATH : '/',
					'domain'   => defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '',
					'secure'   => is_ssl(),
					'httponly' => false,
					'samesite' => 'Lax',
				)
			);
			$_COOKIE['housemajik_search_url'] = $safe;
		}
	}

	/**
	 * URL to return to after a listing detail view.
	 */
	public static function get_search_page_url() {
		if ( ! empty( $_COOKIE['housemajik_search_url'] ) ) {
			$stored = esc_url_raw( wp_unslash( $_COOKIE['housemajik_search_url'] ) );
			$safe   = wp_validate_redirect( $stored, false );
			if ( $safe ) {
				return $safe;
			}
		}

		$referer = wp_get_referer();
		if ( $referer ) {
			return $referer;
		}

		return home_url( '/' );
	}
}
