<?php
/**
 * Email functionality using wp_mail.
 */
class Housemajik_Email {

	/**
	 * Send broker brief on registration.
	 */
	public static function send_broker_brief( $name, $email, $phone, $session_id ) {
		global $wpdb;
		
		// Get session data
		$sessions_table = $wpdb->prefix . 'housemajik_sessions';
		$session = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM $sessions_table WHERE session_id = %s ORDER BY created_at DESC LIMIT 1",
			$session_id
		) );
		
		if ( ! $session ) {
			return false;
		}
		
		$search_params = json_decode( $session->search_params, true );
		$results_shown = json_decode( $session->results_shown, true );
		
		// Get reactions
		$reactions_table = $wpdb->prefix . 'housemajik_reactions';
		$reactions = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM $reactions_table WHERE session_id = %s",
			$session_id
		), ARRAY_A );
		
		// Get AI summary
		$ai_summary = Housemajik_AI::summarize_for_broker( $search_params, $reactions );
		
		// Build email
		$broker_email = get_option( 'housemajik_broker_email', 'mlake@redlake.tv' );
		$broker_name = get_option( 'housemajik_broker_name', 'Suzanne Gonzalez' );
		$brokerage = get_option( 'housemajik_brokerage_name', 'Keys of Dreams Brokery' );
		
		$subject = sprintf( 'New Lead: %s - Housemagik', $name );
		
		$message = self::build_broker_brief_html( 
			$name, 
			$email, 
			$phone, 
			$search_params, 
			$results_shown, 
			$reactions,
			$ai_summary
		);
		
		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . get_option( 'housemajik_sender_name', get_bloginfo( 'name' ) ) . ' <' . get_option( 'housemajik_sender_email', get_option( 'admin_email' ) ) . '>',
			'Reply-To: ' . $email,
		);
		
		return wp_mail( $broker_email, $subject, $message, $headers );
	}

	/**
	 * Send alert confirmation to buyer.
	 */
	public static function send_alert_confirmation( $name, $email, $search_params ) {
		$subject = 'Your Housemagik Search Alert is Active';
		
		$message = sprintf(
			"<html><body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>\n" .
			"<h2 style='color: #4a5568;'>Your Search Alert is Active</h2>\n" .
			"<p>Hi %s,</p>\n" .
			"<p>We'll email you when new listings match your search:</p>\n" .
			"<div style='background: #f7fafc; padding: 15px; border-left: 4px solid #4299e1; margin: 20px 0;'>\n" .
			"<strong>What you're looking for:</strong><br>\n%s\n</div>\n" .
			"<p><strong>Location:</strong> %s</p>\n" .
			"<p><strong>Budget:</strong> Up to $%s</p>\n" .
			"<p><strong>Bedrooms:</strong> %d (%s) | <strong>Bathrooms:</strong> %.1f (%s)</p>\n" .
			"<p style='margin-top: 30px; font-size: 12px; color: #718096;'>To unsubscribe or manage your alerts, <a href='%s'>click here</a>.</p>\n" .
			"<p style='font-size: 12px; color: #718096;'>%s<br>%s</p>\n" .
			"</body></html>",
			esc_html( $name ),
			nl2br( esc_html( $search_params['dream_home'] ) ),
			esc_html( $search_params['location'] ),
			number_format( $search_params['max_price'] ),
			$search_params['beds'],
			$search_params['beds_mode'] === 'exactly' ? 'exactly' : 'at least',
			$search_params['baths'],
			$search_params['baths_mode'] === 'exactly' ? 'exactly' : 'at least',
			home_url( '/manage-alerts/' ),
			get_option( 'housemajik_broker_name', 'Suzanne Gonzalez' ),
			get_option( 'housemajik_brokerage_name', 'Keys of Dreams Brokery' )
		);
		
		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . get_option( 'housemajik_sender_name', get_bloginfo( 'name' ) ) . ' <' . get_option( 'housemajik_sender_email', get_option( 'admin_email' ) ) . '>',
		);
		
		return wp_mail( $email, $subject, $message, $headers );
	}

	/**
	 * Send alert email with new matches.
	 */
	public static function send_alert_email( $alert, $listings ) {
		if ( empty( $listings ) ) {
			return false;
		}
		
		$search_params = json_decode( $alert['search_params'], true );
		
		// Get user's previous reactions for context
		global $wpdb;
		$reactions_table = $wpdb->prefix . 'housemajik_reactions';
		$reactions = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM $reactions_table WHERE email = %s ORDER BY created_at DESC LIMIT 10",
			$alert['email']
		), ARRAY_A );
		
		$subject = sprintf( 'New Homes Match Your Search (%d %s)', 
			count( $listings ),
			count( $listings ) === 1 ? 'listing' : 'listings'
		);
		
		$message = self::build_alert_email_html( $alert, $listings, $search_params, $reactions );
		
		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . get_option( 'housemajik_sender_name', get_bloginfo( 'name' ) ) . ' <' . get_option( 'housemajik_sender_email', get_option( 'admin_email' ) ) . '>',
		);
		
		// Send to buyer
		$buyer_sent = wp_mail( $alert['email'], $subject, $message, $headers );
		
		// Copy broker
		$broker_email = get_option( 'housemajik_broker_email', 'mlake@redlake.tv' );
		$broker_subject = sprintf( 'Alert Sent: %s - %d New Matches', $alert['name'], count( $listings ) );
		$broker_message = sprintf(
			"<p>Alert sent to: %s (%s)</p>\n%s",
			esc_html( $alert['name'] ),
			esc_html( $alert['email'] ),
			$message
		);
		wp_mail( $broker_email, $broker_subject, $broker_message, $headers );
		
		return $buyer_sent;
	}

	/**
	 * Build broker brief HTML.
	 */
	private static function build_broker_brief_html( $name, $email, $phone, $search_params, $results_shown, $reactions, $ai_summary ) {
		$html = "<html><body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>\n";
		$html .= "<h2 style='color: #4a5568;'>New Lead from Housemagik</h2>\n";
		
		// Contact info
		$html .= "<div style='background: #edf2f7; padding: 15px; margin: 20px 0;'>\n";
		$html .= sprintf( "<p><strong>Name:</strong> %s</p>\n", esc_html( $name ) );
		$html .= sprintf( "<p><strong>Email:</strong> <a href='mailto:%s'>%s</a></p>\n", esc_attr( $email ), esc_html( $email ) );
		if ( ! empty( $phone ) ) {
			$html .= sprintf( "<p><strong>Phone:</strong> %s</p>\n", esc_html( $phone ) );
		}
		$html .= "</div>\n";
		
		// AI Summary
		if ( ! empty( $ai_summary['summary'] ) ) {
			$html .= "<h3 style='color: #2d3748;'>What They Want</h3>\n";
			$html .= "<p>" . esc_html( $ai_summary['summary'] ) . "</p>\n";
			
			if ( ! empty( $ai_summary['patterns'] ) ) {
				$html .= "<h4>Patterns from Their Feedback:</h4>\n<ul>\n";
				foreach ( $ai_summary['patterns'] as $pattern ) {
					$html .= "<li>" . esc_html( $pattern ) . "</li>\n";
				}
				$html .= "</ul>\n";
			}
		}
		
		// Search criteria
		$html .= "<h3 style='color: #2d3748;'>Search Criteria</h3>\n";
		$html .= "<div style='background: #f7fafc; padding: 15px; border-left: 4px solid #4299e1;'>\n";
		$html .= "<p><strong>Dream Home:</strong><br>" . nl2br( esc_html( $search_params['dream_home'] ) ) . "</p>\n";
		if ( ! empty( $search_params['dont_want'] ) ) {
			$html .= "<p><strong>Don't Want:</strong><br>" . nl2br( esc_html( $search_params['dont_want'] ) ) . "</p>\n";
		}
		$html .= sprintf( "<p><strong>Location:</strong> %s</p>\n", esc_html( $search_params['location'] ) );
		$html .= sprintf( 
			"<p><strong>Beds:</strong> %d (%s) | <strong>Baths:</strong> %.1f (%s) | <strong>Max Price:</strong> $%s</p>\n",
			$search_params['beds'],
			$search_params['beds_mode'] === 'exactly' ? 'exactly' : 'at least',
			$search_params['baths'],
			$search_params['baths_mode'] === 'exactly' ? 'exactly' : 'at least',
			number_format( $search_params['max_price'] )
		);
		$html .= "</div>\n";
		
		// Listings shown
		$html .= sprintf( "<h3 style='color: #2d3748;'>Listings Shown (%d)</h3>\n", count( $results_shown ) );
		
		// Reactions
		if ( ! empty( $reactions ) ) {
			$html .= "<h4>Their Feedback:</h4>\n";
			foreach ( $reactions as $reaction ) {
				$html .= "<div style='background: #fff; border: 1px solid #e2e8f0; padding: 10px; margin: 10px 0;'>\n";
				$html .= sprintf( "<p><strong>Property:</strong> %s</p>\n", esc_html( $reaction['listing_id'] ) );
				if ( ! empty( $reaction['what_like'] ) ) {
					$html .= sprintf( "<p style='color: #38a169;'><strong>Liked:</strong> %s</p>\n", esc_html( $reaction['what_like'] ) );
				}
				if ( ! empty( $reaction['what_dislike'] ) ) {
					$html .= sprintf( "<p style='color: #e53e3e;'><strong>Disliked:</strong> %s</p>\n", esc_html( $reaction['what_dislike'] ) );
				}
				$html .= "</div>\n";
			}
		} else {
			$html .= "<p>No feedback provided yet.</p>\n";
		}
		
		$html .= "<p style='margin-top: 30px; font-size: 12px; color: #718096;'>Lead generated: " . current_time( 'mysql' ) . "</p>\n";
		$html .= "</body></html>";
		
		return $html;
	}

	/**
	 * Build alert email HTML.
	 */
	private static function build_alert_email_html( $alert, $listings, $search_params, $reactions ) {
		$html = "<html><body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>\n";
		$html .= sprintf( "<h2 style='color: #4a5568;'>Hi %s, we found new homes for you!</h2>\n", esc_html( $alert['name'] ) );
		
		foreach ( $listings as $listing ) {
			// Generate AI why-line
			$why = Housemajik_AI::generate_alert_why_line( $listing, $search_params, $reactions );
			
			$html .= "<div style='background: #fff; border: 1px solid #e2e8f0; padding: 20px; margin: 20px 0;'>\n";
			
			// Photo
			if ( ! empty( $listing['photos'][0] ) ) {
				$html .= sprintf( 
					"<img src='%s' alt='%s' style='width: 100%%; max-width: 600px; height: auto;'>\n",
					esc_url( $listing['photos'][0] ),
					esc_attr( $listing['address'] )
				);
			}
			
			// Details
			$html .= sprintf( "<h3 style='color: #2d3748; margin-top: 15px;'>%s, %s</h3>\n", 
				esc_html( $listing['address'] ),
				esc_html( $listing['city'] )
			);
			$html .= sprintf( "<p style='font-size: 24px; color: #4299e1; font-weight: bold;'>$%s</p>\n",
				number_format( $listing['price'] )
			);
			$html .= sprintf( "<p>%d beds | %.1f baths%s</p>\n",
				$listing['beds'],
				$listing['baths'],
				! empty( $listing['garage'] ) ? ' | ' . esc_html( $listing['garage'] ) : ''
			);
			
			// Why line
			$html .= sprintf( 
				"<p style='background: #ebf8ff; padding: 10px; border-left: 3px solid #4299e1;'><strong>Why we sent this:</strong> %s</p>\n",
				esc_html( $why )
			);
			
			// View button
			$html .= sprintf( 
				"<p><a href='%s' style='display: inline-block; background: #4299e1; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 4px;'>View Details</a></p>\n",
				esc_url( home_url( '/property/' . $listing['id'] ) )
			);
			
			$html .= "</div>\n";
		}
		
		// Footer
		$html .= sprintf( 
			"<p style='margin-top: 30px; font-size: 12px; color: #718096;'>%s<br>%s<br><a href='%s'>Manage your alerts</a> | <a href='%s'>Unsubscribe</a></p>\n",
			get_option( 'housemajik_broker_name', 'Suzanne Gonzalez' ),
			get_option( 'housemajik_brokerage_name', 'Keys of Dreams Brokery' ),
			home_url( '/manage-alerts/' ),
			home_url( '/unsubscribe/?email=' . urlencode( $alert['email'] ) )
		);
		
		$html .= "</body></html>";
		
		return $html;
	}
}
