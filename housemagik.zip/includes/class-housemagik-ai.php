<?php
/**
 * Anthropic Claude AI integration.
 */
class Housemajik_AI {

	/**
	 * Parse dream home and don't-want descriptions into structured search parameters.
	 */
	public static function parse_search_intent( $dream_home, $dont_want ) {
		$api_key = self::get_api_key();
		
		if ( ! $api_key ) {
			return array(
				'hard_filters' => array(),
				'soft_preferences' => array(),
				'exclusions' => array(),
				'ambiguous' => array(),
			);
		}
		
		if ( ! Housemajik_Security::check_ai_cap() ) {
			return array(
				'error' => 'Daily AI usage limit reached. Please try again tomorrow.',
			);
		}
		
		$prompt = self::build_parse_prompt( $dream_home, $dont_want );
		$response = self::call_anthropic_api( $prompt, array(
			'type' => 'parse',
			'max_tokens' => 1000,
		) );
		
		if ( is_wp_error( $response ) ) {
			return array(
				'error' => $response->get_error_message(),
			);
		}
		
		Housemajik_Security::increment_ai_usage();
		
		return $response;
	}

	/**
	 * Rank listings and generate why-lines.
	 */
	public static function rank_listings( $listings, $search_params, $ai_preferences ) {
		$api_key = self::get_api_key();
		
		if ( ! $api_key || empty( $listings ) ) {
			// Fallback: return listings as-is with simple why-lines
			return self::generate_fallback_rankings( $listings, $search_params );
		}
		
		if ( ! Housemajik_Security::check_ai_cap() ) {
			return self::generate_fallback_rankings( $listings, $search_params );
		}
		
		$prompt = self::build_ranking_prompt( $listings, $search_params, $ai_preferences );
		$response = self::call_anthropic_api( $prompt, array(
			'type' => 'rank',
			'max_tokens' => 2000,
		) );
		
		if ( is_wp_error( $response ) ) {
			return self::generate_fallback_rankings( $listings, $search_params );
		}
		
		Housemajik_Security::increment_ai_usage();
		
		return $response;
	}

	/**
	 * Generate why-line for alert email.
	 */
	public static function generate_alert_why_line( $listing, $search_params, $user_reactions = array() ) {
		$api_key = self::get_api_key();
		
		if ( ! $api_key ) {
			return 'New listing matching your saved search.';
		}
		
		if ( ! Housemajik_Security::check_ai_cap() ) {
			return 'New listing matching your saved search.';
		}
		
		$prompt = self::build_alert_why_prompt( $listing, $search_params, $user_reactions );
		$response = self::call_anthropic_api( $prompt, array(
			'type' => 'why',
			'max_tokens' => 200,
		) );
		
		if ( is_wp_error( $response ) ) {
			return 'New listing matching your saved search.';
		}
		
		Housemajik_Security::increment_ai_usage();
		
		return $response;
	}

	/**
	 * Summarize user preferences for broker brief.
	 */
	public static function summarize_for_broker( $search_params, $reactions ) {
		$api_key = self::get_api_key();
		
		if ( ! $api_key || empty( $reactions ) ) {
			return array(
				'summary' => '',
				'patterns' => array(),
			);
		}
		
		if ( ! Housemajik_Security::check_ai_cap() ) {
			return array(
				'summary' => '',
				'patterns' => array(),
			);
		}
		
		$prompt = self::build_broker_summary_prompt( $search_params, $reactions );
		$response = self::call_anthropic_api( $prompt, array(
			'type' => 'summarize',
			'max_tokens' => 1500,
		) );
		
		if ( is_wp_error( $response ) ) {
			return array(
				'summary' => '',
				'patterns' => array(),
			);
		}
		
		Housemajik_Security::increment_ai_usage();
		
		return $response;
	}

	/**
	 * Call Anthropic API.
	 */
	private static function call_anthropic_api( $prompt, $options = array() ) {
		$api_key = self::get_api_key();
		
		if ( ! $api_key ) {
			return new WP_Error( 'no_api_key', 'Anthropic API key not configured.' );
		}
		
		$model = get_option( 'housemajik_ai_model', 'claude-3-haiku-20240307' );
		$max_tokens = isset( $options['max_tokens'] ) ? $options['max_tokens'] : 1000;
		
		$body = array(
			'model' => $model,
			'max_tokens' => $max_tokens,
			'messages' => array(
				array(
					'role' => 'user',
					'content' => $prompt,
				),
			),
		);
		
		$response = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
			'timeout' => 30,
			'headers' => array(
				'Content-Type' => 'application/json',
				'x-api-key' => $api_key,
				'anthropic-version' => '2023-06-01',
			),
			'body' => wp_json_encode( $body ),
		) );
		
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		
		$status_code = wp_remote_retrieve_response_code( $response );
		if ( $status_code !== 200 ) {
			$body = wp_remote_retrieve_body( $response );
			return new WP_Error( 'api_error', 'Anthropic API error: ' . $body );
		}
		
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
		
		if ( ! isset( $data['content'][0]['text'] ) ) {
			return new WP_Error( 'invalid_response', 'Invalid API response.' );
		}
		
		$text = $data['content'][0]['text'];
		
		// Parse JSON response if expected
		if ( in_array( $options['type'], array( 'parse', 'rank', 'summarize' ) ) ) {
			$parsed = json_decode( $text, true );
			if ( json_last_error() === JSON_ERROR_NONE ) {
				return $parsed;
			}
		}
		
		return $text;
	}

	/**
	 * Build parse prompt.
	 */
	private static function build_parse_prompt( $dream_home, $dont_want ) {
		$prompt = "You are a real estate search assistant. Parse the buyer's natural language descriptions into structured search criteria.\n\n";
		$prompt .= "BUYER'S DREAM HOME:\n" . $dream_home . "\n\n";
		
		if ( ! empty( $dont_want ) ) {
			$prompt .= "WHAT BUYER DOESN'T WANT:\n" . $dont_want . "\n\n";
		}
		
		$prompt .= "Extract the following in strict JSON format:\n";
		$prompt .= "{\n";
		$prompt .= '  "hard_filters": ["Clear requirements that can be filtered: pool, single-story, etc."],';
		$prompt .= "\n";
		$prompt .= '  "soft_preferences": ["Preferences for ranking: quiet, natural light, modern, etc."],';
		$prompt .= "\n";
		$prompt .= '  "exclusions": ["Things to avoid from don\'t-want section"],';
		$prompt .= "\n";
		$prompt .= '  "ambiguous": ["Unclear terms that need clarification"]';
		$prompt .= "\n}\n\n";
		$prompt .= "Return ONLY valid JSON. Be specific and actionable.";
		
		return $prompt;
	}

	/**
	 * Build ranking prompt.
	 */
	private static function build_ranking_prompt( $listings, $search_params, $ai_preferences ) {
		$prompt = "You are a real estate assistant. Rank these listings and explain why each matches the buyer's needs.\n\n";
		$prompt .= "BUYER WANTS:\n" . $search_params['dream_home'] . "\n\n";
		
		if ( ! empty( $search_params['dont_want'] ) ) {
			$prompt .= "BUYER DOESN'T WANT:\n" . $search_params['dont_want'] . "\n\n";
		}
		
		$prompt .= "LISTINGS (remarks only, do not invent facts):\n";
		foreach ( $listings as $idx => $listing ) {
			$prompt .= sprintf(
				"%d. %s, %s - $%s - %d bed, %.1f bath - %s\n",
				$idx + 1,
				$listing['address'],
				$listing['city'],
				number_format( $listing['price'] ),
				$listing['beds'],
				$listing['baths'],
				substr( $listing['remarks'], 0, 200 )
			);
		}
		
		$prompt .= "\nReturn strict JSON:\n";
		$prompt .= "{\n";
		$prompt .= '  "rankings": [';
		$prompt .= "\n";
		$prompt .= '    {"listing_index": 0, "score": 95, "why": "One factual sentence explaining the match"},';
		$prompt .= "\n    ...\n";
		$prompt .= "  ]\n}\n\n";
		$prompt .= "Rules:\n";
		$prompt .= "- Score 0-100 based on match quality\n";
		$prompt .= "- 'why' must be ONE sentence, factual, citing actual listing features\n";
		$prompt .= "- Never claim features not in the remarks\n";
		$prompt .= "- If exclusions apply, score lower but still explain honestly\n";
		$prompt .= "- Return ONLY valid JSON";
		
		return $prompt;
	}

	/**
	 * Build alert why prompt.
	 */
	private static function build_alert_why_prompt( $listing, $search_params, $user_reactions ) {
		$prompt = "You are a real estate assistant. Explain in ONE sentence why this new listing matches the buyer's saved search";
		
		if ( ! empty( $user_reactions ) ) {
			$prompt .= " and their previous feedback";
		}
		
		$prompt .= ".\n\n";
		$prompt .= "ORIGINAL SEARCH:\n" . $search_params['dream_home'] . "\n\n";
		
		if ( ! empty( $user_reactions ) ) {
			$prompt .= "BUYER'S PREVIOUS FEEDBACK:\n";
			foreach ( $user_reactions as $reaction ) {
				if ( ! empty( $reaction['what_like'] ) ) {
					$prompt .= "Liked: " . $reaction['what_like'] . "\n";
				}
				if ( ! empty( $reaction['what_dislike'] ) ) {
					$prompt .= "Disliked: " . $reaction['what_dislike'] . "\n";
				}
			}
			$prompt .= "\n";
		}
		
		$prompt .= sprintf(
			"NEW LISTING:\n%s, %s - $%s - %d bed, %.1f bath\n%s\n\n",
			$listing['address'],
			$listing['city'],
			number_format( $listing['price'] ),
			$listing['beds'],
			$listing['baths'],
			$listing['remarks']
		);
		
		$prompt .= "Write ONE factual sentence (under 25 words) explaining why we sent this. Use only facts from the listing.";
		
		return $prompt;
	}

	/**
	 * Build broker summary prompt.
	 */
	private static function build_broker_summary_prompt( $search_params, $reactions ) {
		$prompt = "You are a real estate broker's assistant. Analyze this buyer's search and feedback to help the broker understand their preferences.\n\n";
		$prompt .= "SEARCH CRITERIA:\n";
		$prompt .= "Dream home: " . $search_params['dream_home'] . "\n";
		$prompt .= "Don't want: " . $search_params['dont_want'] . "\n";
		$prompt .= "Location: " . $search_params['location'] . "\n";
		$prompt .= sprintf( "Beds: %d (%s) | Baths: %.1f (%s) | Max price: $%s\n\n",
			$search_params['beds'],
			$search_params['beds_mode'],
			$search_params['baths'],
			$search_params['baths_mode'],
			number_format( $search_params['max_price'] )
		);
		
		$prompt .= "FEEDBACK ON SHOWN LISTINGS:\n";
		foreach ( $reactions as $reaction ) {
			$prompt .= "Property: " . $reaction['address'] . "\n";
			if ( ! empty( $reaction['what_like'] ) ) {
				$prompt .= "  Liked: " . $reaction['what_like'] . "\n";
			}
			if ( ! empty( $reaction['what_dislike'] ) ) {
				$prompt .= "  Disliked: " . $reaction['what_dislike'] . "\n";
			}
			$prompt .= "\n";
		}
		
		$prompt .= "Return strict JSON:\n";
		$prompt .= "{\n";
		$prompt .= '  "summary": "2-3 sentence overview of what this buyer wants",';
		$prompt .= "\n";
		$prompt .= '  "patterns": ["Bullet point pattern 1", "Bullet point pattern 2", ...]';
		$prompt .= "\n}\n\n";
		$prompt .= "Patterns should identify themes in their feedback (e.g., 'Consistently prefers updated kitchens', 'Dislikes busy streets').";
		
		return $prompt;
	}

	/**
	 * Fallback rankings without AI.
	 */
	private static function generate_fallback_rankings( $listings, $search_params ) {
		$rankings = array();

		foreach ( $listings as $idx => $listing ) {
			$rankings[] = array(
				'listing_index' => $idx,
				'score' => 70,
				'why' => self::human_why_line( $listing, $search_params ),
			);
		}

		return array( 'rankings' => $rankings );
	}

	/**
	 * One conversational sentence from remarks and what the buyer typed.
	 */
	private static function human_why_line( $listing, $search_params ) {
		$remarks = isset( $listing['remarks'] ) ? trim( $listing['remarks'] ) : '';
		$first   = '';
		if ( $remarks ) {
			$parts = preg_split( '/(?<=[.!?])\s+/', $remarks, 2 );
			$first = isset( $parts[0] ) ? rtrim( $parts[0], ". \t\n\r" ) : '';
		}

		$dream = strtolower( isset( $search_params['dream_home'] ) ? $search_params['dream_home'] : '' );
		$avoid = strtolower( isset( $search_params['dont_want'] ) ? $search_params['dont_want'] : '' );
		$hooks = array();
		$pairs = array(
			'mountain'  => 'those mountain views',
			'view'      => 'the views',
			'pool'      => 'the pool',
			'modern'    => 'the more modern feel',
			'secluded'  => 'a quieter, more private lot',
			'quiet'     => 'the quieter setting',
			'kitchen'   => 'the kitchen',
			'yard'      => 'the backyard',
			'acre'      => 'the lot',
			'light'     => 'the open, brighter rooms',
			'garage'    => 'the garage',
		);

		foreach ( $pairs as $needle => $phrase ) {
			if ( $dream && false !== strpos( $dream, $needle ) && ( ! $remarks || false !== stripos( $remarks, $needle ) ) ) {
				$hooks[] = $phrase;
			}
		}

		if ( $avoid && ( false !== strpos( $avoid, 'highway' ) || false !== strpos( $avoid, 'traffic' ) ) ) {
			if ( false !== stripos( $remarks, 'cul-de-sac' ) || false !== stripos( $remarks, 'quiet' ) || false !== stripos( $remarks, 'preserve' ) ) {
				$hooks[] = 'sitting off the busy roads';
			}
		}

		if ( $first && ! empty( $hooks ) ) {
			return $first . ' — that fits ' . $hooks[0] . ' you mentioned.';
		}

		if ( $first ) {
			return $first . ' That is what stands out on this one.';
		}

		return sprintf(
			'This %s home in %s is the closest match we have to what you described.',
			isset( $listing['beds'] ) ? (int) $listing['beds'] . '-bedroom' : '',
			isset( $listing['city'] ) ? $listing['city'] : 'the area'
		);
	}

	/**
	 * Get API key from wp-config.php constant.
	 */
	private static function get_api_key() {
		if ( defined( 'ANTHROPIC_API_KEY' ) ) {
			return ANTHROPIC_API_KEY;
		}
		
		return false;
	}
}
