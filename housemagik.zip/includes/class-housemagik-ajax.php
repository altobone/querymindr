<?php
/**
 * AJAX request handlers.
 */
class Housemajik_Ajax {

	/**
	 * Handle search request.
	 */
	public function handle_search() {
		Housemajik_Security::verify_ajax_nonce();
		Housemajik_Security::check_honeypot();
		Housemajik_Security::check_rate_limit( 'search' );
		
		$params = Housemajik_Security::sanitize_search_params( $_POST );
		
		// Validate required fields
		if ( empty( $params['dream_home'] ) ) {
			wp_send_json_error( array( 'message' => 'Please describe your dream home.' ) );
		}
		
		if ( empty( $params['location'] ) ) {
			wp_send_json_error( array( 'message' => 'Please specify a location.' ) );
		}
		
		// Get data source
		$data_source = get_option( 'housemajik_data_source', 'sample' );
		
		// Get listings based on hard filters
		if ( $data_source === 'armls' && Housemajik_ARMLS::is_configured() ) {
			$listings = Housemajik_ARMLS::get_listings( $params );
			if ( is_wp_error( $listings ) ) {
				// Fall back to sample data
				$listings = Housemajik_Sample_Data::get_listings( $params );
			}
		} else {
			$listings = Housemajik_Sample_Data::get_listings( $params );
		}

		if ( empty( $listings ) ) {
			$session_id = Housemajik_Security::get_session_id();
			$search_url = isset( $_POST['search_url'] ) ? esc_url_raw( wp_unslash( $_POST['search_url'] ) ) : '';
			Housemajik_Security::set_search_page_url( $search_url );
			$this->save_search_session( $session_id, $params, array() );
			wp_send_json_success( array(
				'results' => array(),
				'empty' => true,
				'message' => 'No listings match your criteria. Try adjusting your filters.',
			) );
		}
		
		// Parse AI preferences
		$ai_preferences = Housemajik_AI::parse_search_intent( $params['dream_home'], $params['dont_want'] );
		
		if ( isset( $ai_preferences['error'] ) ) {
			// Proceed without AI parsing
			$ai_preferences = array(
				'hard_filters' => array(),
				'soft_preferences' => array(),
				'exclusions' => array(),
			);
		}
		
		// Rank and add why-lines
		$ranked = Housemajik_AI::rank_listings( $listings, $params, $ai_preferences );
		
		// Sort by score and take top matches
		if ( isset( $ranked['rankings'] ) ) {
			usort( $ranked['rankings'], function( $a, $b ) {
				return $b['score'] - $a['score'];
			});
			
			$top_rankings = array_slice( $ranked['rankings'], 0, 8 );
			
			$results = array();
			foreach ( $top_rankings as $ranking ) {
				$idx = $ranking['listing_index'];
				if ( isset( $listings[ $idx ] ) ) {
					$listing = $listings[ $idx ];
					$listing['why'] = $ranking['why'];
					$listing['score'] = $ranking['score'];
					$results[] = $listing;
				}
			}
		} else {
			$results = array_slice( $listings, 0, 8 );
		}
		
		// Save session
		$session_id = Housemajik_Security::get_session_id();
		$search_url = isset( $_POST['search_url'] ) ? esc_url_raw( wp_unslash( $_POST['search_url'] ) ) : '';
		Housemajik_Security::set_search_page_url( $search_url );
		$this->save_search_session( $session_id, $params, $results );
		
		// Check if empty
		if ( empty( $results ) ) {
			wp_send_json_success( array(
				'results' => array(),
				'empty' => true,
				'message' => 'No listings match your criteria. Try adjusting your filters.',
			) );
		}
		
		wp_send_json_success( array(
			'results' => $results,
			'session_id' => $session_id,
			'show_registration' => false,
		) );
	}

	/**
	 * Handle save reaction.
	 */
	public function handle_save_reaction() {
		Housemajik_Security::verify_ajax_nonce();
		
		$session_id = Housemajik_Security::get_session_id();
		$listing_id = isset( $_POST['listing_id'] ) ? sanitize_text_field( $_POST['listing_id'] ) : '';
		$what_like = isset( $_POST['what_like'] ) ? sanitize_textarea_field( $_POST['what_like'] ) : '';
		$what_dislike = isset( $_POST['what_dislike'] ) ? sanitize_textarea_field( $_POST['what_dislike'] ) : '';
		
		if ( empty( $listing_id ) ) {
			wp_send_json_error( array( 'message' => 'Invalid listing.' ) );
		}
		
		global $wpdb;
		$table = $wpdb->prefix . 'housemajik_reactions';
		
		// Check if reaction exists
		$existing = $wpdb->get_row( $wpdb->prepare(
			"SELECT id FROM $table WHERE session_id = %s AND listing_id = %s",
			$session_id,
			$listing_id
		) );
		
		if ( $existing ) {
			// Update
			$wpdb->update(
				$table,
				array(
					'what_like' => $what_like,
					'what_dislike' => $what_dislike,
					'updated_at' => current_time( 'mysql' ),
				),
				array(
					'id' => $existing->id,
				),
				array( '%s', '%s', '%s' ),
				array( '%d' )
			);
		} else {
			// Insert
			$wpdb->insert(
				$table,
				array(
					'session_id' => $session_id,
					'listing_id' => $listing_id,
					'what_like' => $what_like,
					'what_dislike' => $what_dislike,
					'created_at' => current_time( 'mysql' ),
					'updated_at' => current_time( 'mysql' ),
				),
				array( '%s', '%s', '%s', '%s', '%s', '%s' )
			);
		}
		
		wp_send_json_success( array( 'message' => 'Notes saved.' ) );
	}

	/**
	 * Handle registration.
	 */
	public function handle_register() {
		Housemajik_Security::verify_ajax_nonce();
		Housemajik_Security::check_honeypot();
		Housemajik_Security::check_rate_limit( 'register' );
		
		$session_id = Housemajik_Security::get_session_id();
		$name = isset( $_POST['name'] ) ? sanitize_text_field( $_POST['name'] ) : '';
		$email = Housemajik_Security::sanitize_email( $_POST['email'] ?? '' );
		$phone = Housemajik_Security::sanitize_phone( $_POST['phone'] ?? '' );
		
		if ( empty( $name ) || empty( $email ) ) {
			wp_send_json_error( array( 'message' => 'Name and email are required.' ) );
		}
		
		if ( ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => 'Invalid email address.' ) );
		}
		
		// Update session with email
		global $wpdb;
		$sessions_table = $wpdb->prefix . 'housemajik_sessions';
		$wpdb->update(
			$sessions_table,
			array( 'email' => $email, 'registered' => 1 ),
			array( 'session_id' => $session_id ),
			array( '%s', '%d' ),
			array( '%s' )
		);
		
		// Update reactions with email
		$reactions_table = $wpdb->prefix . 'housemajik_reactions';
		$wpdb->update(
			$reactions_table,
			array( 'email' => $email ),
			array( 'session_id' => $session_id ),
			array( '%s' ),
			array( '%s' )
		);
		
		// Send broker brief
		Housemajik_Email::send_broker_brief( $name, $email, $phone, $session_id );
		
		wp_send_json_success( array( 
			'message' => 'Registration complete! Check your email for confirmation.',
		) );
	}

	/**
	 * Handle save alert.
	 */
	public function handle_save_alert() {
		Housemajik_Security::verify_ajax_nonce();
		Housemajik_Security::check_honeypot();
		Housemajik_Security::check_rate_limit( 'alert' );
		
		$session_id = Housemajik_Security::get_session_id();
		$name = isset( $_POST['name'] ) ? sanitize_text_field( $_POST['name'] ) : '';
		$email = Housemajik_Security::sanitize_email( $_POST['email'] ?? '' );
		$phone = Housemajik_Security::sanitize_phone( $_POST['phone'] ?? '' );
		
		if ( empty( $name ) || empty( $email ) ) {
			wp_send_json_error( array( 'message' => 'Name and email are required.' ) );
		}
		
		if ( ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => 'Invalid email address.' ) );
		}
		
		// Get session search params
		global $wpdb;
		$sessions_table = $wpdb->prefix . 'housemajik_sessions';
		$session = $wpdb->get_row( $wpdb->prepare(
			"SELECT search_params FROM $sessions_table WHERE session_id = %s ORDER BY created_at DESC LIMIT 1",
			$session_id
		) );
		
		if ( ! $session ) {
			wp_send_json_error( array( 'message' => 'Session not found.' ) );
		}
		
		$search_params = json_decode( $session->search_params, true );
		
		// Save alert
		$alerts_table = $wpdb->prefix . 'housemajik_alerts';
		$wpdb->insert(
			$alerts_table,
			array(
				'name' => $name,
				'email' => $email,
				'phone' => $phone,
				'search_params' => wp_json_encode( $search_params ),
				'dream_home' => $search_params['dream_home'],
				'dont_want' => $search_params['dont_want'],
				'active' => 1,
				'frequency' => get_option( 'housemajik_alert_frequency', 'daily' ),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		);
		
		// Send confirmation email
		Housemajik_Email::send_alert_confirmation( $name, $email, $search_params );
		
		wp_send_json_success( array( 
			'message' => 'Alert saved! You\'ll receive email updates when new matches appear.',
		) );
	}

	/**
	 * Save search session.
	 */
	private function save_search_session( $session_id, $params, $results ) {
		global $wpdb;
		$table = $wpdb->prefix . 'housemajik_sessions';
		
		$result_ids = array_map( function( $listing ) {
			return $listing['id'];
		}, $results );
		
		$wpdb->insert(
			$table,
			array(
				'session_id' => $session_id,
				'search_params' => wp_json_encode( $params ),
				'results_shown' => wp_json_encode( $result_ids ),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * Check if registration popup should show.
	 */
	private function should_show_registration( $session_id ) {
		// Check cookie
		if ( isset( $_COOKIE['housemajik_registered'] ) ) {
			return false;
		}
		
		// Check if already registered this session
		global $wpdb;
		$table = $wpdb->prefix . 'housemajik_sessions';
		$registered = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $table WHERE session_id = %s AND registered = 1",
			$session_id
		) );
		
		return (int) $registered === 0;
	}
}
