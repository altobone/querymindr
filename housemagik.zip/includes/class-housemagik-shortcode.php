<?php
/**
 * [housemagik] shortcode.
 */
class Housemajik_Shortcode {

	/**
	 * Render shortcode.
	 */
	public function render( $atts ) {
		$atts = shortcode_atts( array(
			'title' => 'Find Your Dream Home',
		), $atts, 'housemagik' );
		
		ob_start();
		include HOUSEMAJIK_PLUGIN_DIR . 'public/views/search-form.php';
		return ob_get_clean();
	}

	/**
	 * Enqueue styles.
	 */
	public function enqueue_styles() {
		wp_enqueue_style( 
			'housemajik-public', 
			HOUSEMAJIK_PLUGIN_URL . 'public/css/housemagik-public.css', 
			array(), 
			HOUSEMAJIK_VERSION 
		);
		
		// Optional: Enqueue Google Fonts
		wp_enqueue_style(
			'housemajik-fonts',
			'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
			array(),
			null
		);
	}

	/**
	 * Enqueue scripts.
	 */
	public function enqueue_scripts() {
		wp_enqueue_script( 
			'housemajik-public', 
			HOUSEMAJIK_PLUGIN_URL . 'public/js/housemagik-public.js', 
			array( 'jquery' ), 
			HOUSEMAJIK_VERSION, 
			true 
		);
		
		wp_localize_script( 'housemajik-public', 'housemajik', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'housemajik_ajax' ),
			'home_url' => home_url(),
			'search_url' => get_permalink(),
			'listing_id' => '',
			'is_detail' => false,
			'data_source' => get_option( 'housemajik_data_source', 'sample' ),
			'idx_disclaimer' => get_option( 'housemajik_idx_disclaimer', '' ),
		) );
	}
}
