<?php
/**
 * Plugin Name: Housemagik
 * Plugin URI: https://housemagik.ai
 * Description: Natural-language home search powered by AI. Find your dream home by describing it.
 * Version: 1.0.0
 * Author: Keys of Dreams Brokery
 * Author URI: https://housemagik.ai
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: housemajik
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( defined( 'HOUSEMAGIK_LOADED' ) ) {
	return;
}
define( 'HOUSEMAGIK_LOADED', true );

if ( ! defined( 'HOUSEMAGIK_BOOTSTRAP_FILE' ) ) {
	define( 'HOUSEMAGIK_BOOTSTRAP_FILE', __FILE__ );
}

define( 'HOUSEMAJIK_VERSION', '1.0.1' );
define( 'HOUSEMAJIK_PLUGIN_DIR', plugin_dir_path( HOUSEMAGIK_BOOTSTRAP_FILE ) );
define( 'HOUSEMAJIK_PLUGIN_URL', plugin_dir_url( HOUSEMAGIK_BOOTSTRAP_FILE ) );
define( 'HOUSEMAJIK_PLUGIN_BASENAME', plugin_basename( HOUSEMAGIK_BOOTSTRAP_FILE ) );

/**
 * The code that runs during plugin activation.
 */
function activate_housemajik() {
	require_once HOUSEMAJIK_PLUGIN_DIR . 'includes/class-housemagik-activator.php';
	Housemajik_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_housemajik() {
	require_once HOUSEMAJIK_PLUGIN_DIR . 'includes/class-housemagik-deactivator.php';
	Housemajik_Deactivator::deactivate();
}

register_activation_hook( HOUSEMAGIK_BOOTSTRAP_FILE, 'activate_housemajik' );
register_deactivation_hook( HOUSEMAGIK_BOOTSTRAP_FILE, 'deactivate_housemajik' );

/**
 * The core plugin class.
 */
require HOUSEMAJIK_PLUGIN_DIR . 'includes/class-housemagik-core.php';

/**
 * Begins execution of the plugin.
 */
function run_housemajik() {
	$plugin = new Housemajik_Core();
	$plugin->run();
}

run_housemajik();
