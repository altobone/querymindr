<?php
/**
 * Fired when the plugin is uninstalled.
 */

// If uninstall not called from WordPress, exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Delete custom tables (optional - uncomment to remove all data on uninstall)
/*
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}housemajik_alerts" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}housemajik_sent_listings" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}housemajik_reactions" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}housemajik_sessions" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}housemajik_cron_log" );
*/

// Delete options
$options = array(
	'housemajik_ai_model',
	'housemajik_ai_daily_cap',
	'housemajik_broker_email',
	'housemajik_broker_name',
	'housemajik_brokerage_name',
	'housemajik_alert_frequency',
	'housemajik_data_source',
	'housemajik_idx_disclaimer',
	'housemajik_sender_email',
	'housemajik_sender_name',
	'housemajik_reply_to_email',
	'housemajik_armls_endpoint',
	'housemajik_armls_username',
	'housemajik_armls_password',
	'housemajik_google_maps_key',
	'housemajik_rate_limit_searches',
	'housemajik_rate_limit_window',
	'housemajik_ai_usage_today',
	'housemajik_ai_usage_date',
);

foreach ( $options as $option ) {
	delete_option( $option );
}
