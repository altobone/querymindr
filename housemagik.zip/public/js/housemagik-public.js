/**
 * Housemagik Public JavaScript
 */

(function($) {
	'use strict';

	let sessionId = null;
	let currentResults = [];

	$(document).ready(function() {
		initializeApp();
	});

	function initializeApp() {
		$('#housemajik-search').on('submit', handleSearch);
		$('#housemajik-register-form').on('submit', handleRegister);
		$('#housemajik-modal-close, #housemajik-skip-register').on('click', closeModal);
		$('.housemajik-modal-overlay').on('click', closeModal);
		$(document).on('click', '.housemajik-reaction-save', handleSaveReaction);
		$(document).on('click', '.housemajik-photo-nav', function(e) {
			e.preventDefault();
		});

		if (typeof housemajik !== 'undefined' && housemajik.is_detail && housemajik.listing_id) {
			maybeShowRegistrationAfterViews(housemajik.listing_id);
		}
	}

	function handleSearch(e) {
		e.preventDefault();

		const $form = $(this);
		const $submit = $('#housemajik-submit');
		const $btnText = $submit.find('.housemajik-btn-text');
		const $spinner = $submit.find('.housemajik-spinner');
		const searchUrl = window.location.href;

		setCookie('housemajik_search_url', searchUrl, 7);

		$submit.prop('disabled', true);
		$btnText.text('Searching...');
		$spinner.show();

		$('#housemajik-results, #housemajik-empty').hide();

		const formData = $form.serialize();

		$.ajax({
			url: housemajik.ajax_url,
			type: 'POST',
			data: formData + '&action=housemajik_search&nonce=' + housemajik.nonce + '&search_url=' + encodeURIComponent(searchUrl),
			success: function(response) {
				if (response.success) {
					sessionId = response.data.session_id;
					currentResults = response.data.results;

					if (response.data.empty) {
						showEmpty(response.data.message);
					} else {
						displayResults(response.data.results);
					}

					setTimeout(function() {
						const target = response.data.empty ? '#housemajik-empty' : '#housemajik-results';
						$(target)[0].scrollIntoView({ behavior: 'smooth', block: 'start' });
					}, 100);
				} else {
					alert(response.data.message || 'Search failed. Please try again.');
				}
			},
			error: function(xhr) {
				console.error('Search error:', xhr);
				var message = 'An error occurred. Please try again.';
				if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
					message = xhr.responseJSON.data.message;
				} else if (xhr.status === 0) {
					message = 'The search timed out or could not reach the server. Please try again.';
				} else if (xhr.status) {
					message = 'Search failed (error ' + xhr.status + '). Please try again.';
				}
				alert(message);
			},
			complete: function() {
				$submit.prop('disabled', false);
				$btnText.text('Show me houses');
				$spinner.hide();
			}
		});
	}

	function displayResults(results) {
		const $container = $('#housemajik-listings');
		$container.empty();

		results.forEach(function(listing) {
			$container.append(buildListingCard(listing));
		});

		$('#housemajik-results').show();
	}

	function buildListingCard(listing) {
		const photo = listing.photos && listing.photos[0] ? listing.photos[0] : '';
		const why = listing.why || '';
		const garage = listing.garage ? `<span class="housemajik-listing-detail">🚗 ${escapeHtml(listing.garage)}</span>` : '';
		const photoCount = 12 + (Math.abs(hashCode(listing.id || '')) % 11);
		const card = $('<div>', { class: 'housemajik-listing-card' });

		if (photo) {
			const stage = $('<div>', { class: 'housemajik-photo-stage' });
			stage.append(
				$('<img>', {
					src: photo,
					alt: listing.address,
					class: 'housemajik-listing-image'
				}),
				$('<button>', {
					type: 'button',
					class: 'housemajik-photo-nav housemajik-photo-prev',
					'aria-label': 'Previous photo',
					text: '‹'
				}),
				$('<button>', {
					type: 'button',
					class: 'housemajik-photo-nav housemajik-photo-next',
					'aria-label': 'Next photo',
					text: '›'
				}),
				$('<span>', {
					class: 'housemajik-photo-count',
					text: '1 / ' + photoCount
				})
			);
			card.append(stage);
		}

		const content = $('<div>', { class: 'housemajik-listing-content' });

		content.append(
			$('<div>', { class: 'housemajik-listing-address', text: listing.address }),
			$('<div>', { class: 'housemajik-listing-city', text: `${listing.city}, ${listing.state} ${listing.zip}` }),
			$('<div>', { class: 'housemajik-listing-price', text: `$${formatNumber(listing.price)}` })
		);

		const details = $('<div>', { class: 'housemajik-listing-details' });
		details.append(
			$('<span>', { class: 'housemajik-listing-detail', text: `🛏️ ${listing.beds} bed` }),
			$('<span>', { class: 'housemajik-listing-detail', text: `🛁 ${listing.baths} bath` })
		);
		if (garage) {
			details.append($(garage));
		}
		content.append(details);

		if (why) {
			content.append(
				$('<div>', { class: 'housemajik-listing-why' })
					.append(
						$('<strong>', { text: 'Why this one:' }),
						document.createTextNode(' ' + why)
					)
			);
		}

		content.append(buildReactionForm(listing.id));

		const actions = $('<div>', { class: 'housemajik-listing-actions' });
		const detailUrl = (housemajik.home_url || '').replace(/\/$/, '') + '/property/' + listing.id;
		actions.append(
			$('<a>', {
				href: detailUrl,
				class: 'housemajik-btn-link',
				text: 'View Full Details'
			})
		);
		content.append(actions);

		if (housemajik.data_source === 'sample') {
			content.append(
				$('<p>', {
					style: 'font-size: 0.75rem; color: #a0aec0; margin-top: 1rem;',
					text: 'Sample listing for demonstration purposes'
				})
			);
		}

		card.append(content);
		return card;
	}

	function buildReactionForm(listingId) {
		const reactions = $('<div>', {
			class: 'housemajik-listing-reactions',
			'data-listing-id': listingId
		});

		reactions.append(
			$('<h4>', { text: 'Your thoughts on this property (optional)' }),
			$('<textarea>', {
				name: 'what_like',
				placeholder: 'What I like about this one...',
				class: 'housemajik-reaction-like'
			}),
			$('<textarea>', {
				name: 'what_dislike',
				placeholder: 'What I don\'t like...',
				class: 'housemajik-reaction-dislike'
			}),
			$('<button>', {
				type: 'button',
				class: 'housemajik-btn housemajik-btn-secondary housemajik-reaction-save',
				text: 'Save Notes'
			})
		);

		return reactions;
	}

	function handleSaveReaction(e) {
		e.preventDefault();

		const $btn = $(this);
		const $container = $btn.closest('.housemajik-listing-reactions');
		const listingId = $container.data('listing-id');
		const whatLike = $container.find('.housemajik-reaction-like').val();
		const whatDislike = $container.find('.housemajik-reaction-dislike').val();

		$btn.prop('disabled', true).text('Saving...');

		$.ajax({
			url: housemajik.ajax_url,
			type: 'POST',
			data: {
				action: 'housemajik_save_reaction',
				nonce: housemajik.nonce,
				listing_id: listingId,
				what_like: whatLike,
				what_dislike: whatDislike
			},
			success: function(response) {
				if (response.success) {
					$btn.text('Saved ✓');
					setTimeout(function() {
						$btn.text('Save Notes');
					}, 2000);
				} else {
					alert(response.data.message || 'Failed to save notes.');
				}
			},
			error: function() {
				alert('An error occurred. Please try again.');
			},
			complete: function() {
				$btn.prop('disabled', false);
			}
		});
	}

	function maybeShowRegistrationAfterViews(listingId) {
		if (getCookie('housemajik_registered')) {
			return;
		}

		var viewed = [];
		try {
			viewed = JSON.parse(getCookie('housemajik_viewed') || '[]');
		} catch (err) {
			viewed = [];
		}

		if (viewed.indexOf(listingId) === -1) {
			viewed.push(listingId);
			setCookie('housemajik_viewed', JSON.stringify(viewed), 7);
		}

		if (viewed.length >= 4) {
			setTimeout(showRegistrationModal, 600);
		}
	}

	function showRegistrationModal() {
		$('#housemajik-register-modal').fadeIn(200);
	}

	function closeModal() {
		$('#housemajik-register-modal').fadeOut(200);
		document.cookie = 'housemajik_registered=1; path=/; max-age=86400';
	}

	function handleRegister(e) {
		e.preventDefault();

		const $form = $(this);
		const $submit = $('#housemajik-register-submit');
		const saveAlert = $('#reg_alert').is(':checked');

		$submit.prop('disabled', true).text('Registering...');

		const formData = $form.serialize();

		$.ajax({
			url: housemajik.ajax_url,
			type: 'POST',
			data: formData + '&action=housemajik_register&nonce=' + housemajik.nonce,
			success: function(response) {
				if (response.success) {
					closeModal();
					alert(response.data.message);
					if (saveAlert) {
						saveSearchAlert();
					}
				} else {
					alert(response.data.message || 'Registration failed.');
				}
			},
			error: function() {
				alert('An error occurred. Please try again.');
			},
			complete: function() {
				$submit.prop('disabled', false).text('Register');
			}
		});
	}

	function saveSearchAlert() {
		$.ajax({
			url: housemajik.ajax_url,
			type: 'POST',
			data: {
				action: 'housemajik_save_alert',
				nonce: housemajik.nonce,
				name: $('#reg_name').val(),
				email: $('#reg_email').val(),
				phone: $('#reg_phone').val()
			}
		});
	}

	function showEmpty(message) {
		$('#housemajik-empty').find('p').first().text(message);
		$('#housemajik-empty').show();
	}

	function formatNumber(num) {
		return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	}

	function escapeHtml(text) {
		const map = {
			'&': '&amp;',
			'<': '&lt;',
			'>': '&gt;',
			'"': '&quot;',
			"'": '&#039;'
		};
		return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
	}

	function hashCode(str) {
		var hash = 0;
		for (var i = 0; i < str.length; i++) {
			hash = ((hash << 5) - hash) + str.charCodeAt(i);
			hash |= 0;
		}
		return hash;
	}

	function setCookie(name, value, days) {
		var expires = '';
		if (days) {
			var date = new Date();
			date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
			expires = '; expires=' + date.toUTCString();
		}
		document.cookie = name + '=' + encodeURIComponent(value) + '; path=/';
	}

	function getCookie(name) {
		var match = document.cookie.match(new RegExp('(?:^|; )' + name.replace(/([.$?*|{}()[\]\\/+^])/g, '\\$1') + '=([^;]*)'));
		return match ? decodeURIComponent(match[1]) : '';
	}

})(jQuery);
