<?php
/**
 * Listing detail page template.
 */
if ( ! defined( 'WPINC' ) ) {
	die;
}

$listing_id = get_query_var( 'housemajik_listing' );

// Get listing data
$data_source = get_option( 'housemajik_data_source', 'sample' );

if ( $data_source === 'armls' && Housemajik_ARMLS::is_configured() ) {
	$listing = Housemajik_ARMLS::get_listing( $listing_id );
	if ( is_wp_error( $listing ) || ! $listing ) {
		$listing = Housemajik_Sample_Data::get_listing( $listing_id );
	}
} else {
	$listing = Housemajik_Sample_Data::get_listing( $listing_id );
}

if ( ! $listing ) {
	wp_redirect( home_url() );
	exit;
}

$maps_key = sanitize_text_field( get_option( 'housemajik_google_maps_key', '' ) );
$listing_lat = isset( $listing['lat'] ) ? (float) $listing['lat'] : 0;
$listing_lng = isset( $listing['lng'] ) ? (float) $listing['lng'] : 0;
$show_map = ( $listing_lat && $listing_lng );

get_header();

$search_back = Housemajik_Security::get_search_page_url();
$mls_photo_count = 12 + ( abs( crc32( $listing['id'] ) ) % 11 );

wp_enqueue_style( 'housemajik-public', HOUSEMAJIK_PLUGIN_URL . 'public/css/housemagik-public.css', array(), HOUSEMAJIK_VERSION );
wp_enqueue_script( 'housemajik-public', HOUSEMAJIK_PLUGIN_URL . 'public/js/housemagik-public.js', array( 'jquery' ), HOUSEMAJIK_VERSION, true );
wp_localize_script( 'housemajik-public', 'housemajik', array(
	'ajax_url'    => admin_url( 'admin-ajax.php' ),
	'nonce'       => wp_create_nonce( 'housemajik_ajax' ),
	'home_url'    => home_url(),
	'search_url'  => $search_back,
	'listing_id'  => $listing_id,
	'is_detail'   => true,
	'data_source' => $data_source,
) );

if ( $show_map && $maps_key ) {
	wp_register_script( 'housemajik-listing-map-init', false, array(), HOUSEMAJIK_VERSION, true );
	wp_enqueue_script( 'housemajik-listing-map-init' );
	wp_add_inline_script(
		'housemajik-listing-map-init',
		'function housemajikInitListingMap(){var el=document.getElementById("housemajik-listing-map");if(!el||typeof google==="undefined"||!google.maps){return;}var lat=parseFloat(el.getAttribute("data-lat"));var lng=parseFloat(el.getAttribute("data-lng"));var title=el.getAttribute("data-title")||"";var position={lat:lat,lng:lng};var map=new google.maps.Map(el,{center:position,zoom:15,mapTypeControl:false,streetViewControl:false,fullscreenControl:true});new google.maps.Marker({position:position,map:map,title:title});}'
	);

	wp_enqueue_script(
		'housemajik-google-maps',
		'https://maps.googleapis.com/maps/api/js?key=' . rawurlencode( $maps_key ) . '&callback=housemajikInitListingMap',
		array( 'housemajik-listing-map-init' ),
		null,
		true
	);
	wp_script_add_data( 'housemajik-google-maps', 'async', true );
	wp_script_add_data( 'housemajik-google-maps', 'defer', true );
}
?>

<div class="housemajik-detail">
	
	<!-- Photos -->
	<div class="housemajik-detail-photos">
		<?php if ( ! empty( $listing['photos'][0] ) ) : ?>
			<div class="housemajik-photo-stage housemajik-photo-stage-detail">
				<img
					src="<?php echo esc_url( $listing['photos'][0] ); ?>"
					alt="<?php echo esc_attr( $listing['address'] ); ?>"
					class="housemajik-detail-photo-main"
					id="main-photo"
				>
				<button type="button" class="housemajik-photo-nav housemajik-photo-prev" aria-label="Previous photo">‹</button>
				<button type="button" class="housemajik-photo-nav housemajik-photo-next" aria-label="Next photo">›</button>
				<span class="housemajik-photo-count">1 / <?php echo (int) $mls_photo_count; ?></span>
			</div>
		<?php endif; ?>
	</div>
	
	<!-- Content -->
	<div class="housemajik-detail-content">
		
		<div class="housemajik-detail-main">
			<h1><?php echo esc_html( $listing['address'] ); ?></h1>
			<p style="font-size: 1.125rem; color: #718096; margin-bottom: 1rem;">
				<?php echo esc_html( $listing['city'] . ', ' . $listing['state'] . ' ' . $listing['zip'] ); ?>
			</p>
			
			<div style="font-size: 2rem; font-weight: 700; color: #4299e1; margin-bottom: 2rem;">
				$<?php echo number_format( $listing['price'] ); ?>
			</div>
			
			<!-- Facts -->
			<div class="housemajik-detail-facts">
				<div class="housemajik-detail-fact">
					<span class="housemajik-detail-fact-label">Bedrooms</span>
					<span class="housemajik-detail-fact-value"><?php echo esc_html( $listing['beds'] ); ?></span>
				</div>
				<div class="housemajik-detail-fact">
					<span class="housemajik-detail-fact-label">Bathrooms</span>
					<span class="housemajik-detail-fact-value"><?php echo esc_html( $listing['baths'] ); ?></span>
				</div>
				<div class="housemajik-detail-fact">
					<span class="housemajik-detail-fact-label">Square Feet</span>
					<span class="housemajik-detail-fact-value"><?php echo number_format( $listing['sqft'] ); ?></span>
				</div>
				<div class="housemajik-detail-fact">
					<span class="housemajik-detail-fact-label">Year Built</span>
					<span class="housemajik-detail-fact-value"><?php echo esc_html( $listing['year_built'] ); ?></span>
				</div>
				<?php if ( ! empty( $listing['garage'] ) ) : ?>
					<div class="housemajik-detail-fact">
						<span class="housemajik-detail-fact-label">Garage</span>
						<span class="housemajik-detail-fact-value"><?php echo esc_html( $listing['garage'] ); ?></span>
					</div>
				<?php endif; ?>
				<?php if ( ! empty( $listing['lot_size'] ) ) : ?>
					<div class="housemajik-detail-fact">
						<span class="housemajik-detail-fact-label">Lot Size</span>
						<span class="housemajik-detail-fact-value"><?php echo esc_html( $listing['lot_size'] ); ?></span>
					</div>
				<?php endif; ?>
			</div>
			
			<!-- Description -->
			<h2 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 1rem;">About This Home</h2>
			<p style="line-height: 1.8; color: #4a5568;">
				<?php echo nl2br( esc_html( $listing['remarks'] ) ); ?>
			</p>
			
			<!-- Map -->
			<?php if ( $show_map ) : ?>
				<h2 style="font-size: 1.5rem; font-weight: 700; margin: 2rem 0 1rem;">Location</h2>
				<?php if ( $maps_key ) : ?>
					<div
						class="housemajik-detail-map"
						id="housemajik-listing-map"
						data-lat="<?php echo esc_attr( $listing_lat ); ?>"
						data-lng="<?php echo esc_attr( $listing_lng ); ?>"
						data-title="<?php echo esc_attr( $listing['address'] ); ?>"
					></div>
				<?php else : ?>
					<div class="housemajik-detail-map">
						<p style="text-align: center; padding-top: 120px; color: #a0aec0;">
							Map unavailable<br>
							<small>Add a Google Maps API key in Housemagik settings</small>
						</p>
					</div>
				<?php endif; ?>
			<?php endif; ?>
			
			<!-- MLS Info -->
			<?php if ( $data_source === 'armls' && ! empty( $listing['id'] ) && strpos( $listing['id'], 'SAMPLE-' ) === false ) : ?>
				<p style="font-size: 0.875rem; color: #718096; margin-top: 2rem;">
					<strong>MLS#:</strong> <?php echo esc_html( $listing['id'] ); ?>
				</p>
			<?php endif; ?>
			
			<?php if ( $data_source === 'sample' ) : ?>
				<p style="font-size: 0.875rem; color: #a0aec0; margin-top: 2rem; padding: 1rem; background: #fef5e7; border-radius: 0.375rem;">
					<strong>Sample Listing:</strong> This is demonstration data for testing purposes.
				</p>
			<?php endif; ?>
			
			<!-- IDX Disclaimer -->
			<?php
			$as_of = wp_date( 'F j, Y', time(), new DateTimeZone( 'America/Phoenix' ) );
			if ( $data_source === 'sample' ) {
				$idx_disclaimer = 'These are demonstration listings for testing. They are not live MLS data. Shown ' . $as_of . '.';
			} else {
				$idx_disclaimer = get_option( 'housemajik_idx_disclaimer', '' );
				$idx_disclaimer = str_replace( '[DATE]', $as_of, $idx_disclaimer );
			}
			if ( ! empty( $idx_disclaimer ) ) :
			?>
				<div style="margin-top: 2rem; padding: 1rem; background: #f7fafc; border-left: 4px solid #cbd5e0; font-size: 0.875rem; color: #718096;">
					<?php echo wp_kses_post( wpautop( $idx_disclaimer ) ); ?>
				</div>
			<?php endif; ?>
		</div>
		
		<!-- Sidebar -->
		<div class="housemajik-detail-sidebar">
			<h3 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 1rem;">
				Interested in this property?
			</h3>
			<p style="color: #718096; margin-bottom: 1.5rem;">
				Contact <?php echo esc_html( get_option( 'housemajik_broker_name', 'Suzanne Gonzalez' ) ); ?> 
				to schedule a showing or learn more.
			</p>
			
			<div style="margin-bottom: 1rem;">
				<strong style="display: block; color: #2d3748; margin-bottom: 0.5rem;">
					<?php echo esc_html( get_option( 'housemajik_broker_name', 'Suzanne Gonzalez' ) ); ?>
				</strong>
				<span style="color: #718096; font-size: 0.95rem;">
					<?php echo esc_html( get_option( 'housemajik_brokerage_name', 'Keys of Dreams Brokery' ) ); ?>
				</span>
			</div>
			
			<a 
				href="mailto:<?php echo esc_attr( get_option( 'housemajik_broker_email', 'mlake@redlake.tv' ) ); ?>?subject=<?php echo rawurlencode( 'Inquiry about ' . $listing['address'] ); ?>" 
				class="housemajik-btn housemajik-btn-primary" 
				style="width: 100%; margin-top: 1.5rem; text-align: center; text-decoration: none;"
			>
				Ask Suzanne
			</a>
			
			<a 
				href="<?php echo esc_url( $search_back ); ?>" 
				class="housemajik-btn housemajik-btn-secondary" 
				style="width: 100%; margin-top: 1rem; text-align: center; text-decoration: none;"
			>
				← Back to Search
			</a>
		</div>
		
	</div>
	
</div>

<div class="housemajik-modal" id="housemajik-register-modal" style="display: none;">
	<div class="housemajik-modal-overlay"></div>
	<div class="housemajik-modal-content">
		<button class="housemajik-modal-close" id="housemajik-modal-close">&times;</button>
		<h3>Love these homes?</h3>
		<p>Register to save your search, add notes to listings, and get alerts when new matches appear.</p>
		<form id="housemajik-register-form" class="housemajik-modal-form">
			<input type="hidden" name="website" value="" class="housemajik-honeypot">
			<div class="housemajik-field">
				<label for="reg_name">Name</label>
				<input type="text" id="reg_name" name="name" required>
			</div>
			<div class="housemajik-field">
				<label for="reg_email">Email</label>
				<input type="email" id="reg_email" name="email" required>
			</div>
			<div class="housemajik-field">
				<label for="reg_phone">Phone (optional)</label>
				<input type="tel" id="reg_phone" name="phone">
			</div>
			<div class="housemajik-field">
				<label class="housemajik-checkbox">
					<input type="checkbox" name="alert" id="reg_alert" checked>
					<span>Email me when new matches appear</span>
				</label>
			</div>
			<p class="housemajik-consent">
				By registering, you agree to receive search results and property alerts.
				Your information will be shared with <?php echo esc_html( get_option( 'housemajik_broker_name', 'Suzanne Gonzalez' ) ); ?>
				at <?php echo esc_html( get_option( 'housemajik_brokerage_name', 'Keys of Dreams Brokery' ) ); ?>.
			</p>
			<div class="housemajik-modal-actions">
				<button type="button" class="housemajik-btn housemajik-btn-secondary" id="housemajik-skip-register">Skip for now</button>
				<button type="submit" class="housemajik-btn housemajik-btn-primary" id="housemajik-register-submit">Register</button>
			</div>
		</form>
	</div>
</div>

<?php
get_footer();
?>
