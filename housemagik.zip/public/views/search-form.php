<?php
/**
 * Search form template.
 */
if ( ! defined( 'WPINC' ) ) {
	die;
}

$data_source = get_option( 'housemajik_data_source', 'sample' );
?>

<div class="housemajik-container" id="housemajik-app">
	
	<!-- Search Form -->
	<div class="housemajik-search-form" id="housemajik-form">
		<div class="housemajik-header">
			<h2><?php echo esc_html( $atts['title'] ); ?></h2>
			<?php if ( $data_source === 'sample' ) : ?>
				<p class="housemajik-sample-notice">
					<span class="housemajik-badge">Sample Data Mode</span>
					Showing demo listings for testing purposes
				</p>
			<?php endif; ?>
		</div>
		
		<form id="housemajik-search" class="housemajik-form">
			<input type="hidden" name="website" value="" class="housemajik-honeypot">
			
			<div class="housemajik-field">
				<label for="dream_home">What is your dream home?</label>
				<textarea 
					id="dream_home" 
					name="dream_home" 
					rows="4" 
					placeholder="Tell us what you're looking for... (e.g., I want a modern home with lots of natural light, a big backyard for kids, and a gourmet kitchen)"
					required
				></textarea>
			</div>
			
			<div class="housemajik-field">
				<label for="dont_want">What don't you want?</label>
				<textarea 
					id="dont_want" 
					name="dont_want" 
					rows="3" 
					placeholder="Tell us what to avoid... (e.g., No busy streets, no HOA, no pool maintenance)"
				></textarea>
			</div>
			
			<div class="housemajik-row">
				<div class="housemajik-field">
					<label for="location">Where?</label>
					<input 
						type="text" 
						id="location" 
						name="location" 
						placeholder="City (e.g., Phoenix, Scottsdale)" 
						required
					>
				</div>
			</div>
			
			<div class="housemajik-row">
				<div class="housemajik-field housemajik-col-half">
					<label for="beds">Bedrooms</label>
					<div class="housemajik-input-group">
						<input 
							type="number" 
							id="beds" 
							name="beds" 
							min="1" 
							max="10" 
							value="3"
						>
						<select name="beds_mode" id="beds_mode">
							<option value="exactly">exactly</option>
							<option value="at_least">at least</option>
						</select>
					</div>
				</div>
				
				<div class="housemajik-field housemajik-col-half">
					<label for="baths">Bathrooms</label>
					<div class="housemajik-input-group">
						<input 
							type="number" 
							id="baths" 
							name="baths" 
							min="1" 
							max="10" 
							step="0.5" 
							value="2"
						>
						<select name="baths_mode" id="baths_mode">
							<option value="exactly">exactly</option>
							<option value="at_least">at least</option>
						</select>
					</div>
				</div>
			</div>
			
			<div class="housemajik-row">
				<div class="housemajik-field housemajik-col-half">
					<label for="max_price">Max Price</label>
					<input 
						type="number" 
						id="max_price" 
						name="max_price" 
						min="0" 
						step="1000" 
						placeholder="500000"
						required
					>
				</div>
				
				<div class="housemajik-field housemajik-col-half">
					<label for="garage">Garage</label>
					<select name="garage" id="garage">
						<option value="dont_care">Don't care</option>
						<option value="yes">Yes</option>
						<option value="no">No</option>
					</select>
				</div>
			</div>
			
			<div class="housemajik-submit">
				<button type="submit" class="housemajik-btn housemajik-btn-primary" id="housemajik-submit">
					<span class="housemajik-btn-text">Show me houses</span>
					<span class="housemajik-spinner" style="display: none;"></span>
				</button>
			</div>
		</form>
	</div>
	
	<!-- Results -->
	<div class="housemajik-results" id="housemajik-results" style="display: none;">
		<div class="housemajik-results-header">
			<h3>Here are your top matches</h3>
		</div>
		<div class="housemajik-listings" id="housemajik-listings"></div>
	</div>
	
	<!-- Empty State -->
	<div class="housemajik-empty" id="housemajik-empty" style="display: none;">
		<h3>No matches found</h3>
		<p>We couldn't find any listings that match all your criteria. Try adjusting your filters or budget.</p>
		<button type="button" class="housemajik-btn housemajik-btn-secondary" onclick="document.getElementById('housemajik-form').scrollIntoView({behavior: 'smooth'})">
			Try Another Search
		</button>
	</div>
	
	<!-- Registration Popup -->
	<div class="housemajik-modal" id="housemajik-register-modal" style="display: none;">
		<div class="housemajik-modal-overlay"></div>
		<div class="housemajik-modal-content">
			<button class="housemajik-modal-close" id="housemajik-modal-close">&times;</button>
			
			<h3>Love these homes?</h3>
			<p>Register to save your search, add notes to listings, and get alerts when new matches appear.</p>
			
			<form id="housemajik-register-form" class="housemajik-modal-form">
				<input type="hidden" name="website" value="" class="housemajik-honeypot">
				
				<div class="housemajik-field">
					<label for="reg_name">Name</label>
					<input type="text" id="reg_name" name="name" required>
				</div>
				
				<div class="housemajik-field">
					<label for="reg_email">Email</label>
					<input type="email" id="reg_email" name="email" required>
				</div>
				
				<div class="housemajik-field">
					<label for="reg_phone">Phone (optional)</label>
					<input type="tel" id="reg_phone" name="phone">
				</div>
				
				<div class="housemajik-field">
					<label class="housemajik-checkbox">
						<input type="checkbox" name="alert" id="reg_alert" checked>
						<span>Email me when new matches appear</span>
					</label>
				</div>
				
				<p class="housemajik-consent">
					By registering, you agree to receive search results and property alerts. 
					Your information will be shared with <?php echo esc_html( get_option( 'housemajik_broker_name', 'Suzanne Gonzalez' ) ); ?> 
					at <?php echo esc_html( get_option( 'housemajik_brokerage_name', 'Keys of Dreams Brokery' ) ); ?>.
				</p>
				
				<div class="housemajik-modal-actions">
					<button type="button" class="housemajik-btn housemajik-btn-secondary" id="housemajik-skip-register">
						Skip for now
					</button>
					<button type="submit" class="housemajik-btn housemajik-btn-primary" id="housemajik-register-submit">
						Register
					</button>
				</div>
			</form>
		</div>
	</div>
	
</div>

<style>
/* Scoped IDX disclaimer */
.housemajik-idx {
	margin-top: 2rem;
	padding: 1rem;
	background: #f7fafc;
	border-left: 4px solid #cbd5e0;
	font-size: 0.875rem;
	color: #718096;
}
</style>

<?php
// Arizona calendar date for the footer stamp (avoids UTC showing the next day).
$as_of = wp_date( 'F j, Y', time(), new DateTimeZone( 'America/Phoenix' ) );
if ( $data_source === 'sample' ) {
	$idx_disclaimer = 'These are demonstration listings for testing. They are not live MLS data. Shown ' . $as_of . '.';
} else {
	$idx_disclaimer = get_option( 'housemajik_idx_disclaimer', '' );
	$idx_disclaimer = str_replace( '[DATE]', $as_of, $idx_disclaimer );
}
if ( ! empty( $idx_disclaimer ) ) :
?>
	<div class="housemajik-idx">
		<?php echo wp_kses_post( wpautop( $idx_disclaimer ) ); ?>
	</div>
<?php endif; ?>
